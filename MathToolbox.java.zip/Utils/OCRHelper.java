package utils;

public class OCRHelper {

    public static String extractMathFromImage(String imagePath) {
        // Future: hook up Tesseract OCR via Tess4J
        System.out.println("OCR not yet implemented. Returning empty string.");
        return "";
    }
}
